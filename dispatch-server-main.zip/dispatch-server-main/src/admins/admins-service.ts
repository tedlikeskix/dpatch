// authentication service
import { db } from '../database/connect';
import { JWT_EXPIRY, JWT_SECRET } from '../config';

// utils
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import {IUser} from "../types";

const AdminsService = {
    getAdminByUserId: (userId: number) => {
        return db
            .select('*')
            .from('admins')
            .where('user_id', userId)
            .first();
    }
};

export default AdminsService;
