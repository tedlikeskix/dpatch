// authentication service
import { db } from '../database/connect';
import { JWT_EXPIRY, JWT_SECRET } from '../config';

// utils
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import {IUser} from "../types";

const DispatchersService = {
    getDispatcherByUserId: (userId: number) => {
        return db
            .select('*')
            .from('dispatchers')
            .where('user_id', userId)
            .first();
    }
};

export default DispatchersService;
