// service for shifts
import {db} from "../database/connect";
import {IAvailability} from "./availabilities-router";

const availabilitiesService = {
    insertAvailability: (aval: IAvailability): Promise<IAvailability> => {
        return db
            .insert(aval)
            .into('availabilities')
            .returning('*')
            .then(([av]) => av)
    },

    getAvailsByDay: (day: string) => {
        return db
            .select(
                'availabilities.id',
                'availabilities.available_on',
                'availabilities.is_am',
                'availabilities.is_pm',
                'availabilities.timeslot_am',
                'availabilities.timeslot_pm',
                'drivers.company',
                'drivers.id AS driver_id',
                'users.first_name',
                'users.last_name'
            )
            .from('availabilities')
            .where('available_on', day)
            .innerJoin('drivers', 'availabilities.driver_id', 'drivers.id')
            .innerJoin('users', 'drivers.user_id', 'users.id');
    },

    getAvailByDriverIdAndDay: (driverId: number | string, day: string) => {
        return db
            .select('*')
            .from('availabilities')
            .where('driver_id', driverId)
            .andWhere('available_on', day)
            .first();
    },

    getAvailsByDriverId: (driverId: number | string) => {
        return db
            .select('*')
            .from('availabilities')
            .where('driver_id', driverId);
    },

    updateAvail: (fields: Partial<IAvailability>): Promise<void> => {
        return db
            .from('availabilities')
            .where('id', fields.id)
            .update(fields)
            .then((res) => {
                console.log('result of insert: ', res)
            })
    },

    updateAvails: async (avails: IAvailability[]) => {
        const trx = await db.transaction();

        console.log(`🏧 Updating ${avails.length} availabilities for driver id ${avails[0].driver_id}`);

        let updatedCount = 0;
        let addedCount = 0;
        let deletedCount = 0;

        try {
            for (const av of avails) {
                const prevAvail = await trx('availabilities')
                    .where('driver_id', av.driver_id)
                    .andWhere('available_on', av.available_on)
                    .first();

                if (prevAvail) {
                    if (!av.is_pm && !av.is_am) {
                        await trx('availabilities')
                            .where('id', prevAvail.id)
                            .delete();
                        deletedCount = deletedCount + 1;
                    } else {
                        await trx('availabilities')
                            .where('id', prevAvail.id)
                            .update({
                                is_am: av.is_am,
                                is_pm: av.is_pm,
                            });

                        updatedCount = updatedCount + 1;
                    }
                } else {
                    await trx('availabilities').insert(av);
                    addedCount = addedCount + 1;
                }
            }

            await trx.commit(); // Commit the changes
            console.log('Transaction committed successfully');
            console.log(`Processed (${avails.length}) Updated (${updatedCount}) Added (${addedCount}) Deleted (${deletedCount})`);
        } catch (error) {
            await trx.rollback(); // Rollback if an error occurred
            console.error('Error in transaction:', error);
        } finally {
            await trx.destroy(); // Destroy the transaction connection
        }
    },

    deleteAvailByDate: (date: string, driverId: number) => {
        return db
            .from('availabilities')
            .where('available_on', date)
            .andWhere('driver_id', driverId)
            .delete();
    }
};

export default availabilitiesService;
