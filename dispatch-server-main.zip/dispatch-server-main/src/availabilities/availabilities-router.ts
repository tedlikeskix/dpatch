// router for shifts
import {json, Router} from 'express';
import availabilitiesService from "./availabilities-service";
import * as path from "path";
import checkUserPermissions from "../middleware/check-permissions";

export interface IAvailability {
    id?: number;
    available_on: string;
    is_am: boolean;
    is_pm: boolean;
    timeslot_am: string | null;
    timeslot_pm: string | null;
    driver_id: number;
    created_at?: Date;
    modified_at?: Date;
}

export interface IDriverChangeAvail {
    available_on: string;
    created_at?: string;
    modified_at?: Date;
    driver_id?: number;
    id?: number;
    is_am: boolean;
    is_pm: boolean;
    timeslot_am?: string | null;
    timeslot_pm?: string | null;
}

// service

const availabilitiesRouter = Router();
const jsonBodyParser = json();

availabilitiesRouter
    .route('/')
    .post(jsonBodyParser, async (req, res, next) => {
        try {
            await checkUserPermissions(req, res, next, ['driver']);

            const avails: IAvailability[] = req.body.avails;

            await availabilitiesService.updateAvails(avails);

            console.log('❇️ Updates were made');

            return res.status(201);
        } catch (err) {
            console.error('err inserting avail: ', err.message);
            next();
        }
    })

availabilitiesRouter
    .route('/:day_selected')
    .get(async (req, res, next) => {
        try {
            await checkUserPermissions(req, res, next, ['dispatcher']);

            const daySelected = req.params.day_selected;
            console.log(`getting avails for ${daySelected}`)

            const avails = await availabilitiesService.getAvailsByDay(daySelected);
            return res.status(200).json(avails);
        } catch (err) {
            console.error('err getting avails: ', err.message);
            next();
        }

    })
    .post(jsonBodyParser, async (req, res, next) => {
        let action;

        try {
            const driverAvail: IDriverChangeAvail = req.body.driverAvail;
            const day_selected: string = req.params.day_selected;

            console.log('🏓 REQ DRIVER CH: ', driverAvail);

            const currAvail = await availabilitiesService.getAvailByDriverIdAndDay(driverAvail.driver_id, driverAvail.available_on);

            if (currAvail) {
                if (!driverAvail.is_am && !driverAvail.is_pm) {
                    await availabilitiesService.deleteAvailByDate(driverAvail.available_on, driverAvail.driver_id);
                    console.log('🏓 DELETED AVAIL')
                    action = 'delete';
                } else {
                    const av = {
                        id: currAvail.id,
                        available_on: driverAvail.available_on,
                        is_am: driverAvail.is_am,
                        is_pm: driverAvail.is_pm
                    }

                    await availabilitiesService.updateAvail(av);
                    console.log('🏓 UPDATED AVAIL');
                    action = 'update';
                }
            } else {
                // new avail
                const av: IAvailability = {
                    available_on: day_selected,
                    driver_id: driverAvail.driver_id,
                    is_am: driverAvail.is_am,
                    is_pm: driverAvail.is_pm,
                    timeslot_am: driverAvail.timeslot_am,
                    timeslot_pm: driverAvail.timeslot_pm
                }

                await availabilitiesService.insertAvailability(av);
                console.log('🏓 CREATED avail!');
                action = 'create';
            }

            return res.status(201).json({ message: `${action} was successful` });
        } catch (err) {
            console.error(err);
            // Make sure to send an error response in case of an error
            return res.status(500).send('An error occurred');
        }
    })
    .patch(jsonBodyParser, async (req, res, next) => {
        try {
            const {avail} = req.body;

            console.log('🏐 Received avail: ', avail);

            const fields: Partial<IAvailability> = {
                id: avail.id,
                timeslot_am: avail.timeslot_am,
                timeslot_pm: avail.timeslot_pm,
            }

            console.log('🏐 Fields to update: ', fields);

            await availabilitiesService.updateAvail(fields);

            console.log('finished updates')

            return res.status(200).json({ message: `updated avail id ${avail.id}`});
        } catch (err) {
            console.error(err);
            // Make sure to send an error response in case of an error
            return res.status(500).send('An error occurred');
        }
    })

export default availabilitiesRouter;
