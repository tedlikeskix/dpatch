import {format} from "date-fns";

export const formattedDateOnly = (date = new Date()) => format(date, 'MM/dd/yy');
