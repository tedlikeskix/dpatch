import {json, Router} from 'express';
import availabilitiesService from "../availabilities/availabilities-service";
import {IAvailability} from "../availabilities/availabilities-router";
import checkUserPermissions from "../middleware/check-permissions";
import DriversService from "./drivers-service";
import UsersService from "../users/users-service";
import {IUser} from "../types";
import {TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_SMS_PHONE} from "../config";
import path from 'path';
import {AwsService} from "../vendors/aws-service";

const fs = require('fs');

// SET UP MULTER

// import multer from 'multer';
// const multerStorage = multer.diskStorage({
//     destination: (req, file, cb) => {
//         cb(null, 'uploads/')
//     },
//     filename: (req, file, cb) => {
//         cb(null, file.originalname)
//     },
// })
// const upload = multer({storage: multerStorage})

const multer  = require('multer')
const upload = multer({ dest: 'uploads/' })

// SET UP GOOGLE STORAGE

const { Storage } = require('@google-cloud/storage');
const storage = new Storage({
    keyFilename: 'roughstock-b0898ce14194.json',
    scopes: ['https://www.googleapis.com/auth/cloud-platform'],
});

// service

const driversRouter = Router();
const jsonBodyParser = json();

driversRouter
    .route('/')
    .get(async (req, res, next) => {
        try {
            await checkUserPermissions(req, res, next, ['dispatcher']);

            const drivers = await DriversService.getAllDrivers();

            return res.status(200).json(drivers);
        } catch (err) {
            console.error('err getting avails: ', err.message);
            next();
        }
    })

driversRouter
    .route('/info')
    .get(async (req, res, next) => {
        try {
            const {driverId} = await checkUserPermissions(req, res, next, ['driver']);

            if (driverId) {
                const driver = await DriversService.getDriverById(driverId);

                return res.status(200).json(driver);
            } else {
                return res.status(400).json({error: 'No driver found'});
            }
        } catch (err) {
            console.error('err getting avails: ', err.message);
            next();
        }
    })

driversRouter
    .post('/upload', upload.single('file'), async (req, res) => {
        try {
            console.log("📷 uploading photo...");

            const file = req.file;

            // Rename the uploaded file with ticket information and timestamp
            const oldFilePath = file.path;
            const ticketNumber = req.body.ticketNumber || 'unknown';
            const driverId = req.body.driverId || 'unknown';
            const newFilename = `Ticket-${ticketNumber}-${driverId}-${Date.now()}${path.extname(file.originalname)}`;
            const newFilePath = `uploads/${newFilename}`;

            console.log("📷 filename: ", newFilename);

            // Rename the file locally
            fs.rename(oldFilePath, newFilePath, async (err) => {
                if (err) {
                    return res.status(500).send('Error in renaming file: ' + err);
                }

                console.log("📷 new photo renamed");

                // Upload the renamed file to Google Cloud Storage
                const bucketName = 'sand-tickets';
                console.log("📷 uploading to ", bucketName);

                try {
                    await storage.bucket(bucketName).upload(newFilePath, {
                        gzip: true,
                        metadata: {
                            cacheControl: 'public, max-age=31536000',
                        },
                    })

                    console.log("📷 uploaded to Google -- able to delete");

                    fs.unlink(newFilePath, (err) => {
                        if (err) {
                            console.error(`Error deleting file: ${err}`);
                        } else {
                            console.log('📷 file deleted successfully');
                        }
                    });

                    res.json({success: true});
                } catch (error) {
                    console.error("Server error:", error);
                    res.status(500).json({success: false, message: "Internal Server Error"});
                }
            });
        } catch (error) {
            console.error("Server error:", error);
            res.status(500).json({success: false, message: "Internal Server Error"});
        }
    });

driversRouter
    .route('/notify')
    .post(jsonBodyParser, async (req, res, next) => {
        let succeeded = 0;
        let failed = 0;

        try {
            await checkUserPermissions(req, res, next, ['dispatcher']);
            const avails: IAvailability[] = req.body.avails;

            const client = require("twilio")(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

            for (const av of avails) {
                const user: IUser = await UsersService.getUserByDriverId(av.driver_id);

                const strings = [];

                strings.push(`Hi ${user.first_name} ${user.last_name},`);
                strings.push(`Roughstock Inc. has scheduled you for ${av.available_on}:`);

                if (av.timeslot_am) {
                    strings.push(`\nMorning ☀️ ${av.timeslot_am} A.M. start time.`);
                }

                if (av.timeslot_pm) {
                    strings.push(`\nEvening 🌙 ${av.timeslot_pm} P.M. start time.`);
                }

                strings.push(`\n\nPlease contact dispatch if your availability changes.`);

                const msg = strings.join(' ');

                console.log(msg);

                client.messages
                    .create({
                        body: msg,
                        from: TWILIO_SMS_PHONE,
                        to: user.phone,
                    })
                    .then((message) => {
                        console.log(`☎️ MSG SENT TO ${user.phone}: `, message);
                        console.log(message.sid);
                        succeeded = succeeded + 1;
                    })
                    .catch((err) => {
                        console.error(`could not send sms to ${user.phone}: `, err.message);
                        failed = failed + 1;
                    })
            }

            return res.json({
                status: 'success',
                succeeded,
                failed,
            })
        } catch (err) {
            console.error('err getting avails: ', err.message);
            return res.json({
                status: 'failed',
                succeeded,
                failed,
            })
        }
    })

driversRouter
    .route('/:id/notify')
    .post((req, res) => {
        try {
            AwsService
                .sendSms('+19525940400', 'testing out text messages')
                .then((result) => {
                if (result.status === 'success') {
                    res.status(200).json({ message: result.message })
                } else {
                    res.status(400).json({ error: result.message })
                }
            })
        } catch (err) {
            res.status(400).json({ error: err.message })
        }
//         const AWS = require('aws-sdk');
//
// // The AWS Region that you want to use to send the message. For a list of
// // AWS Regions where the Amazon Pinpoint API is available, see
// // https://docs.aws.amazon.com/pinpoint/latest/apireference/.
//         const aws_region = "us-east-1";
//
// // The phone number or short code to send the message from. The phone number
// // or short code that you specify has to be associated with your Amazon Pinpoint
// // account. For best results, specify long codes in E.164 format.
//         const originationNumber = "+18775480654";
//
// // The recipient's phone number.  For best results, you should specify the
// // phone number in E.164 format.
//         const destinationNumber = "+16124178853";
//
// // The content of the SMS message.
//         const message = "This message was sent through Amazon Pinpoint "
//             + "using the AWS SDK for JavaScript in Node.js. Reply STOP to "
//             + "opt out.";
//
// // The Amazon Pinpoint project/application ID to use when you send this message.
// // Make sure that the SMS channel is enabled for the project or application
// // that you choose.
//         const applicationId = "672c7edb7df9496ea152829ceac96e27";
//
// // The type of SMS message that you want to send. If you plan to send
// // time-sensitive content, specify TRANSACTIONAL. If you plan to send
// // marketing-related content, specify PROMOTIONAL.
//         const messageType = "TRANSACTIONAL";
//
// // The registered keyword associated with the originating short code.
//         const registeredKeyword = "KEYWORD_113702695308";
//
// // The sender ID to use when sending the message. Support for sender ID
// // varies by country or region. For more information, see
// // https://docs.aws.amazon.com/pinpoint/latest/userguide/channels-sms-countries.html
//         const senderId = "MySenderID";
//
// // Specify the region.
//         AWS.config.update({region:aws_region});
//
// // Specify that you're using a shared credentials file, and optionally specify
// // the profile that you want to use.
//         const credentials = new AWS.SharedIniFileCredentials({profile: 'default'});
//         AWS.config.credentials = credentials;
//
// //Create a new Pinpoint object.
//         const pinpoint = new AWS.Pinpoint();
//
// // Specify the parameters to pass to the API.
//         const params = {
//             ApplicationId: applicationId,
//             MessageRequest: {
//                 Addresses: {
//                     [destinationNumber]: {
//                         ChannelType: 'SMS'
//                     }
//                 },
//                 MessageConfiguration: {
//                     SMSMessage: {
//                         Body: message,
//                         Keyword: registeredKeyword,
//                         MessageType: messageType,
//                         OriginationNumber: originationNumber,
//                         SenderId: senderId,
//                     }
//                 }
//             }
//         };
//
// //Try to send the message.
//         pinpoint.sendMessages(params, function(err, data) {
//             // If something goes wrong, print an error message.
//             if(err) {
//                 console.log(err.message);
//                 // Otherwise, show the unique ID for the message.
//                 res.status(400).json({error: err.message})
//             } else {
//                 const msg = "Message sent! " + data['MessageResponse']['Result'][destinationNumber]['StatusMessage']
//                 console.log(msg);
//                 res.status(200).json({message: msg})
//             }
//         });
    })

driversRouter
    .route('/:id/availabilities')
    .get(async (req, res, next) => {
        try {
            await checkUserPermissions(req, res, next, ['driver', 'dispatcher']);

            const driverId = req.params.id;
            const avails = await availabilitiesService.getAvailsByDriverId(driverId);

            return res.status(200).json(avails);
        } catch (err) {
            console.error('err getting avails: ', err.message);
            next();
        }
    })

export default driversRouter;
