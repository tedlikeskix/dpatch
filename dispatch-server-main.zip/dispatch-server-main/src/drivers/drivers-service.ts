// authentication service
import { db } from '../database/connect';
import { JWT_EXPIRY, JWT_SECRET } from '../config';

// utils
import * as bcrypt from 'bcryptjs';
import * as jwt from 'jsonwebtoken';
import {IUser} from "../types";

const DriversService = {
    getDriverById: (id: number) => {
        return db
            .select(
                'drivers.*',
                'users.first_name as firstName',
                'users.last_name as lastName'
            )
            .from('drivers')
            .where('drivers.id', id)
            .innerJoin('users', 'drivers.user_id', 'users.id')
            .first();
    },
    getAllDrivers: () => {
        return db
            .select(
                'drivers.*',
                'users.first_name as firstName',
                'users.last_name as lastName'
            )
            .from('drivers')
            .innerJoin('users', 'drivers.user_id', 'users.id'); // Inner join with users table
    },
    getDriverByUserId: (userId: number) => {
        return db
            .select('*')
            .from('drivers')
            .where('user_id', userId)
            .first();
    }
};

export default DriversService;
