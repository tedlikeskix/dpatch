import { db } from '../database/connect';
import {IUser} from "../types";

export interface IUserWithRoles extends IUser {
        driver_id: number | null;
        dispatcher_id: number | null;
        admin_id: number | null;
}

const UsersService = {
    getUserById: (id: number) => {
        return db
            .select('*')
            .from('users')
            .where('id', id)
            .first();
    },
    getUserByPhone: (phone: string) => {
        return db
            .select('*')
            .from('users')
            .where('phone', phone)
            .first();
    },
    getUserWithRolesByPhone: (phone: string): Promise<IUserWithRoles> => {
        return db
            .select(
                'users.*',
                'drivers.id as driver_id',
                'dispatchers.id as dispatcher_id',
                'admins.id as admin_id'
            )
            .from('users')
            .where('phone', phone)
            .leftJoin('drivers', 'users.id', 'drivers.user_id')
            .leftJoin('dispatchers', 'users.id', 'dispatchers.user_id')
            .leftJoin('admins', 'users.id', 'admins.user_id')
            .first();
    },
    getUserWithRolesById: (userId: number): Promise<IUserWithRoles> => {
        return db
            .select(
                'users.*',
                'drivers.id as driver_id',
                'dispatchers.id as dispatcher_id',
                'admins.id as admin_id'
            )
            .from('users')
            .where('users.id', userId)
            .leftJoin('drivers', 'users.id', 'drivers.user_id')
            .leftJoin('dispatchers', 'users.id', 'dispatchers.user_id')
            .leftJoin('admins', 'users.id', 'admins.user_id')
            .first();
    },
    getUserByDriverId: (driverId: number) => {
        return db
            .select('users.*')
            .from('drivers')
            .leftJoin('users', 'drivers.user_id', 'users.id')
            .where('drivers.id', driverId)
            .first();
    }
};

export default UsersService;
