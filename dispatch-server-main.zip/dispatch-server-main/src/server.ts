// tslint:disable-next-line:no-var-requires
import { NODE_ENV, PORT } from './config';

// middleware and configuration
import express from "express";
import morgan from "morgan";
import cors from "cors";
import helmet from "helmet";

// routers
import {addDbMiddleware} from "./middleware/add-db";
import availabilitiesRouter from "./availabilities/availabilities-router";
import driversRouter from "./drivers/drivers-router";
import authRouter from "./auth/auth-router";
import vendorsRouter from "./vendors/vendors-router";

// main express root
const app = express();
const morganOption = (NODE_ENV === 'production') ? 'tiny' : 'common';

// initialize middleware
app.use(morgan(morganOption));
app.use(cors());
app.use(helmet());
app.use(addDbMiddleware);
app.use(express.urlencoded({ extended: true }));

// basic root to confirm server is running
app.get('/', (req, res) => {
  res.send("Server's buns are buttered");
});

// basic root to confirm server is running
app.get('/api', (req, res) => {
  res.send("API READY");
});

// api endpoints
app.use('/api/auth', authRouter);
app.use('/api/availabilities', availabilitiesRouter);
app.use('/api/drivers', driversRouter);
app.use('/api/vendors', vendorsRouter);

// define error handler
const errorHandler = (err: any, req, res) => {
  let response;
  if (NODE_ENV === 'production') {
    response = {
      error: {
        message: 'server error'
      }
    };
  } else {
    // tslint:disable-next-line:no-console
    console.error(err);
    response = {
      message: err.message, err
    };
  }
  res.status(500).json(response);
};

// use error handler
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server listening at http://localhost:${PORT}`)
})
