import { db } from '../database/connect';
import {ISMSEvent} from "../types";

const SmsService = {
    insertEvent: (event: ISMSEvent) => {
        return db
            .insert(event)
            .into('sms_events')
            .returning('*')
            .then(([ev]) => ev)
    },
};

export default SmsService;
