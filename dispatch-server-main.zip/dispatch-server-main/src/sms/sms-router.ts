import {json, Router} from 'express';
import {ISMSEvent} from "../types";
import SmsService from "./sms-service";

// service

const smsRouter = Router();
const jsonBodyParser = json();

smsRouter
    .route('/')
    .post(jsonBodyParser, async (req, res, next) => {
        try {
            const body = req.body;

            const strBody = JSON.stringify(body);

            const ev: ISMSEvent = {
                event: strBody,
                service: "twilio"

            }

            await SmsService.insertEvent(ev);

            next();
        } catch (err) {
            console.error('err getting avails: ', err.message);
            next();
        }
    })

export default smsRouter;
