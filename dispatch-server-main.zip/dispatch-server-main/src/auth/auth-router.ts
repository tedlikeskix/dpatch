import * as express from 'express';
import requireAuth from '../middleware/jwt-auth';

const jsonBodyParser = express.json();
const authRouter = express.Router();

// service
import AuthService from './auth-service';

import { TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_VERIFY_SID } from "../config";
import UsersService, {IUserWithRoles} from "../users/users-service";

// refresh client token
authRouter
    .post('/refresh', requireAuth, (req, res) => {
        const sub = req['user'].user_name;
        const payload = {user_id: req['user'].id};
        const user_id = payload.user_id;
        res.send({
            authToken: AuthService.createJwt(sub, payload),
            user_id
        })
    });

authRouter
    .post('/otp', jsonBodyParser, (req, res, next) => {
        const {body} = req;
        const phone = body.phone;

        console.log('here is what was sent: ', phone);

        const client = require("twilio")(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

        client.verify.v2
            .services(TWILIO_VERIFY_SID)
            .verifications.create({to: phone, channel: "sms"})
            .then((verification) => {
                console.log(verification.status);
                console.log(verification);
                return res.json({
                    status: 'success',
                    message: 'otp has been sent'
                })
            })
            .catch((err) => res.status(500).json({message: `could not send otp: ${err.message}`}))
    })

authRouter
    .post('/otp/code', jsonBodyParser, async (req, res, next) => {
        try {
            const {body} = req;
            const code = body.code;
            const phone = body.phone;

            console.log(`posting code ${code} for # ${phone}`)

            const client = require("twilio")(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN);

            const twilioResponse = await client
                .verify
                .v2
                .services(TWILIO_VERIFY_SID)
                .verificationChecks
                .create({to: phone, code});

            console.log(twilioResponse);

            if (twilioResponse.status === 'approved') {
                const user: IUserWithRoles = await UsersService.getUserWithRolesByPhone(phone);

                if (!user) {
                    console.log('no user found');
                    return res.status(200).json({error: 'user does not exist'});
                }

                console.log('user: ', user)

                const userId = user.id
                const driverId = user.driver_id ?? null
                const dispatcherId = user.dispatcher_id ?? null
                const adminId = user.admin_id ?? null

                const sub = phone;
                const payload = { userId, driverId, dispatcherId, adminId }

                return res.json({
                    authToken: AuthService.createJwt(sub, payload),
                    userId,
                    firstName: user.first_name,
                    lastName: user.last_name,
                    driverId,
                    dispatcherId,
                    adminId,
                })
            } else {
                console.log('twilio is not approved');
                return res.status(200).json({error: 'code not accepted'});
            }
        } catch (err) {
            return res
                .status(500)
                .json({message: `could not send otp: ${err.message}`})
        }
    })

export default authRouter;
