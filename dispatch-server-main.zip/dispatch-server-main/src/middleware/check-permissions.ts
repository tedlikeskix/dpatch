// jwt authentication
import AuthService from '../auth/auth-service';
import UsersService, {IUserWithRoles} from "../users/users-service";

export interface IJwtPayload {
    userId: number;
    driverId: number;
    dispatcherId: number;
    adminId: number;
    iat: number;
    exp: number;
    sub: string;
}

export interface ICheckPermissionsResult {
    userId: number;
    driverId: number;
    dispatcherId: number;
    adminId: number;
    phone: string
}

export type Role = 'driver' | 'admin' | 'dispatcher';

const checkUserPermissions = async (req, res, next, roles: Role[]): Promise<ICheckPermissionsResult> => {
    const authToken = req.get('Authorization') || '';
    let bearerToken;

    console.log('🥏 req.get: ', req.get('Authorization'));
    console.log('🥏 req.headers.authorization: ', req.headers.authorization);

    if (!authToken.toLowerCase().startsWith('bearer ')) {
        console.log(`⛔️ user has no bearer token`);
        return res.status(204).json({message: 'You do not have permission'});
    } else {
        // slice off 'bearer ' from the token
        bearerToken = authToken.slice(7, authToken.length)
        console.log('🥏 bearerToken: ', bearerToken);
    }

    try {
        console.log('🥏 getting paylod...');
        const payload: IJwtPayload = AuthService.verifyJwt(bearerToken);

        console.log(`Checking user id ${payload.userId} for [${roles.join(', ')}] role(s)...`);

        const hasPermission = roles.some((r) => {
            if (r === 'driver' && payload.driverId !== null) {
                return true;
            }

            if (r === 'dispatcher' && payload.dispatcherId !== null) {
                return true;
            }

            if (r === 'admin' && payload.adminId !== null) {
                return true;
            }

            return false;
        })

        if (!hasPermission) {
            console.log(`⛔ user has no permission for roles: ${roles.join(', ')}`);
            return res.status(204).json({message: 'You do not have permission'});
        }

        // for (const r of roles) {
        //     if (r==='driver') {
        //         if (user.driver_id === null) {
        //             console.log(`⛔ user has no ${r} permission`);
        //             return res.status(204).json({message: 'You do not have permission'});
        //         }
        //     }
        //
        //     if (r==='dispatcher') {
        //         if (user.dispatcher_id === null) {
        //             console.log(`⛔ user has no ${r} permission`);
        //             return res.status(204).json({message: 'You do not have permission'});
        //         }
        //     }
        //
        //     if (r==='admin') {
        //         if (user.admin_id === null) {
        //             console.log(`⛔ user has no ${r} permission`);
        //             return res.status(204).json({message: 'You do not have permission'});
        //         }
        //     }
        // }

        console.log('✅ User has correct permissions');

        return {
            userId: payload.userId,
            phone: payload.sub,
            driverId: payload.driverId,
            dispatcherId: payload.dispatcherId,
            adminId: payload.adminId,
        };
    } catch (error) {
        console.error('could not verify user in request', error);
        return res.status(400).json({ error: error.message });
    }
}

export default checkUserPermissions;
