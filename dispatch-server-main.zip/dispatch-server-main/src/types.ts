export interface IUser {
    id: number;
    first_name: string;
    last_name: string;
    phone: string;
    created_at: Date;
    modified_at: Date;
    deactivated_at: Date | null;
}

export interface IGratitude {
    id: number;
    text: string;
    user_id: number;
    created_at: Date;
}

export interface IInventory {
    id: number;
    user_id: number;
    created_at: Date;
    completed_at: Date;
}

export interface IUsage {
    num_of_inventories: number,
    num_of_inventory_items: number,
    num_of_review_items: number,
    latest_inventory_created_at: Date | null,
    latest_inventory_item_created_at: Date | null,
    daily_streak: number;
    num_of_inventory_items_processed?: number;
    num_of_ai_processed_inventory_items?: number;
    num_of_helpful_suggestions?: number;
    num_of_unhelpful_suggestions?: number;
    num_of_completed_suggestions?: number;
}

export interface ISMSEvent {
    id?: number;
    service: string;
    event: JSON | string;
    created_at?: Date;
}
