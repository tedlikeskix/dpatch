CREATE TABLE routes (
    id SERIAL PRIMARY KEY,
    pickup VARCHAR(255) NOT NULL,
    unload VARCHAR(255) NOT NULL,
    miles INTEGER NOT NULL,
    per_ton decimal(12,2) NOT NULL,
    sub_per_ton decimal(12,2) NOT NULL,
    driver_pay decimal(12,2) NOT NULL,
    map_url TEXT
);
