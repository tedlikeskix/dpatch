CREATE TABLE availabilities (
    id SERIAL PRIMARY KEY,
    available_on TEXT NOT NULL,
    is_am BOOLEAN NOT NULL,
    is_pm BOOLEAN NOT NULL,
    timeslot_am TEXT,
    timeslot_pm TEXT,
    driver_id INTEGER REFERENCES drivers(id) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    modified_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
