CREATE TABLE sms_events (
    id SERIAL PRIMARY KEY,
    service TEXT NOT NULL,
    event JSON NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
