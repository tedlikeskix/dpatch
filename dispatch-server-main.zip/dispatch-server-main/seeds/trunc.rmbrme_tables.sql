TRUNCATE
    users,
    people,
    rmbrs RESTART IDENTITY CASCADE;
