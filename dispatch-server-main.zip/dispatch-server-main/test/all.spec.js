// All tests
import './app.spec';
import './auth-endpoint.spec';
import './user-endpoint.spec';
import './protected-endpoint.spec';
import './person-endpoint.spec';
import './rmbr-endpoint.spec';
